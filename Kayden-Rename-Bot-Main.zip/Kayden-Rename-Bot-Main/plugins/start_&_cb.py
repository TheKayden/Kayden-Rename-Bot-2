"""
Apache License 2.0
Copyright (c) 2022 @PYRO_BOTZ

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Telegram Link : https://t.me/PYRO_BOTZ 
Repo Link : https://github.com/TEAM-PYRO-BOTZ/PYRO-RENAME-BOT
License Link : https://github.com/TEAM-PYRO-BOTZ/PYRO-RENAME-BOT/blob/main/LICENSE
"""

import random
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, ForceReply, CallbackQuery
from helper.database import db
from config import Config, Txt
from utils import check_verification, get_token, verify_user, check_token
from info import VERIFY, VERIFY_TUTORIAL, BOT_USERNAME
  

@Client.on_message(filters.private & filters.command("start"))
async def start(client, message):
    user = message.from_user
    await db.add_user(client, message)                
    button = InlineKeyboardMarkup([[
        InlineKeyboardButton("ᴅᴇᴠᴇʟᴏᴘᴇʀ", callback_data='dev')
        ],[
        InlineKeyboardButton('Uᴩᴅᴀᴛᴇꜱ', callback_data='update'),
        InlineKeyboardButton('Sᴜᴩᴩᴏʀᴛ', callback_data='bot')
        ],[
        InlineKeyboardButton('ᴀʙᴏᴜᴛ', callback_data='about'),
        InlineKeyboardButton('Hᴇʟᴩ', callback_data='help')
    ]])
    if Config.START_PIC:
        await message.reply_photo(Config.START_PIC, caption=Txt.START_TXT.format(user.mention), reply_markup=button)       
    else:
        await message.reply_text(text=Txt.START_TXT.format(user.mention), reply_markup=button, disable_web_page_preview=True)
   
    # Verification link handling
    data = message.command[1] if len(message.command) > 1 else None
    if data and data.split("-", 1)[0] == "verify":
        userid = data.split("-", 2)[1]
        token = data.split("-", 3)[2]
        if str(user.id) != str(userid):
            return await message.reply_text(
                text="<b>Invalid link or Expired link!</b>",
                protect_content=True
            )
        is_valid = await check_token(client, userid, token)
        if is_valid:
            await verify_user(client, userid, token)
            await message.reply_text(
                text=f"<b>Hey {user.mention}, You are successfully verified!\nNow you have unlimited access to all files till today midnight.</b>",
                protect_content=True
            )
        else:
            return await message.reply_text(
                text="<b>Invalid link or Expired link!</b>",
                protect_content=True
            )

@Client.on_message(filters.private & filters.command(["donate", "d"]))
async def donate(client, message):
	text = Txt.DONATE_TXT
	keybord = InlineKeyboardMarkup([
        			[InlineKeyboardButton("Admin",url = "https://t.me/IllegalDeveloperBot"), 
        			InlineKeyboardButton("✗ Close",callback_data = "close") ]])
	await message.reply_text(text = text,reply_markup = keybord)

@Client.on_message(filters.private & filters.command(["add_channel"]))
async def forwardchannelset(client, message):
    if len(message.command) != 2:
        await message.reply_text("Please use the correct format: /add_channel <channel_id>")
        return

    try:
        channel_id = int(message.command[1])
        user_id = message.from_user.id
        addforwardchannel(user_id, channel_id)
        await message.reply_text(f"Forward channel has been set: {channel_id}")
    except ValueError:
        await message.reply_text("Invalid channel ID format. Please provide a numeric value.")
    except Exception as e:
        await message.reply_text(f"An error occurred: {str(e)}")


@Client.on_message(filters.private & filters.command(["remove_channel"]))
async def forwardchanneldeset(client, message):
    if len(message.command) != 2:
        await message.reply_text("Please use the correct format: /remove_channel <channel_id>")
        return

    try:
        channel_id = int(message.command[1])
        user_id = message.from_user.id
        removeforwardchannel(user_id)
        await message.reply_text(f"Forward channel has been removed from: {channel_id}")
    except ValueError:
        await message.reply_text("Invalid channel ID format. Please provide a numeric value.")
    except Exception as e:
        await message.reply_text(f"An error occurred: {str(e)}")


@Client.on_message(filters.private & filters.command(["view_channel"]))
async def forwardchannelview(client, message):
    user_id = message.from_user.id
    try:
        channel_id = getforwardchannel(user_id)
        if channel_id:
            await message.reply_text(f"Your current forward channel ID is: {channel_id}")
        else:
            await message.reply_text("No forward channel is set.")
    except Exception as e:
        await message.reply_text(f"An error occurred: {str(e)}")


@Client.on_callback_query()
async def cb_handler(client, query: CallbackQuery):
    data = query.data 
    if data == "start":
        await query.message.edit_text(
            text=Txt.START_TXT.format(query.from_user.mention),
            disable_web_page_preview=True,
            reply_markup = InlineKeyboardMarkup([[
                InlineKeyboardButton("ᴅᴇᴠᴇʟᴏᴘᴇʀ", callback_data='dev')
                ],[
                InlineKeyboardButton('Uᴩᴅᴀᴛᴇꜱ', callback_data='update'),
                InlineKeyboardButton('Sᴜᴩᴩᴏʀᴛ', callback_data='bot')
                ],[
                InlineKeyboardButton('Aʙᴏᴜᴛ', callback_data='about'),
                InlineKeyboardButton('Hᴇʟᴩ', callback_data='help')
            ]])
        )
    elif data == "help":
        await query.message.edit_text(
            text=Txt.HELP_TXT,
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup([[
                #⚠️ don't change source code & source link ⚠️ #
                InlineKeyboardButton("ᴛʜᴜᴍʙɴᴀɪʟ", url="https://t.me/Illegal_Developer"),
                InlineKeyboardButton("ᴄᴀᴘᴛɪᴏɴ", url='https://t.me/IllegalDeveloperBot')
                ],[
		InlineKeyboardButton("ᴄᴜꜱᴛᴏᴍ ꜰɪʟᴇ ɴᴀᴍᴇ", callback_data = "close")
	        ],[
                InlineKeyboardButton("✗ Cʟᴏꜱᴇ", callback_data = "close"),
                InlineKeyboardButton("« Bᴀᴄᴋ", callback_data = "start")
            ]])            
        )
    elif data == "illegal":
        await query.message.edit_text(
            text=Txt.ILLEGAL_TXT.format(client.mention),
            disable_web_page_preview = True,
            reply_markup=InlineKeyboardMarkup([[
                #⚠️ don't change source code & source link ⚠️ #
                InlineKeyboardButton("ᴍᴏᴠɪᴇ ʙᴏᴛ¹", url="https://t.me/AnythingFilterBot"),
                InlineKeyboardButton("ᴍᴏᴠɪᴇ ʙᴏᴛ²", url="https://t.me/iPopcornBeta_Bot")           
                ],[
                InlineKeyboardButton("4ɢʙ ʀᴇɴᴀᴍᴇ ʙᴏᴛ", url="https://t.me/Illegal4GbRenameBot")
                ],[
                InlineKeyboardButton("ꜰɪʟᴇ ꜱᴛᴏʀᴀɢᴇ ʙᴏᴛ", url="https://t.me/IllegalFileStorageBot")
                ],[
                InlineKeyboardButton("✗ Cʟᴏꜱᴇ", callback_data = "close"),
                InlineKeyboardButton("« Bᴀᴄᴋ", callback_data = "start")
            ]])            
        )
    elif data == "about":
        await query.message.edit_text(
            text=Txt.ABOUT_TXT.format(client.mention),
            disable_web_page_preview = True,
            reply_markup=InlineKeyboardMarkup([[
                #⚠️ don't change source code & source link ⚠️ #
                InlineKeyboardButton("ᴏᴜʀ ʙᴏᴛꜱ", callback_data = "illegal")
                ],[
                InlineKeyboardButton("✗ Cʟᴏꜱᴇ", callback_data = "close"),
                InlineKeyboardButton("Developer", callback_data = "dev")
            ]])            
        )
    elif data == "update":
        await query.message.edit_text(
            text=Txt.UPDATE_TXT.format(query.from_user.mention),
            disable_web_page_preview = True,
            reply_markup=InlineKeyboardMarkup([[
                #⚠️ don't change source code & source link ⚠️ #
                InlineKeyboardButton("ᴊᴏɪɴ ᴜᴘᴅᴀᴛᴇ ᴄʜᴀɴɴᴇʟ", url="https://t.me/Illegal_Developer")
                ],[
                InlineKeyboardButton("ꜱᴜᴘᴘᴏʀᴛ ɢʀᴏᴜᴘ", url="https://t.me/Illegal_Supports"),
                InlineKeyboardButton("ᴍᴏᴠɪᴇ ɢʀᴏᴜᴘ", url="https://t.me/HDMovieHouse4K")
	        ],[
		InlineKeyboardButton("« Bᴀᴄᴋ", callback_data = "start"),
            ]])            
        )
    elif data == "bot":
        await query.message.edit_text(
            text=Txt.BOT_TXT.format(query.from_user.mention),
            disable_web_page_preview = True,
            reply_markup=InlineKeyboardMarkup([[
                #⚠️ don't change source code & source link ⚠️ #
                InlineKeyboardButton("4ɢʙ ʀᴇɴᴀᴍᴇ ʙᴏᴛ", url="https://t.me/File_Renamer_4Gb_V4Bot")
                ],[
                InlineKeyboardButton("ᴍᴏᴠɪᴇ ʙᴏᴛ", url="https://t.me/iPopcornBeta_Bot"),
                InlineKeyboardButton("ꜱᴛʀᴇᴀᴍ ʙᴏᴛ", url="https://t.me/File_Stream_iBot")
	        ],[
		InlineKeyboardButton("« Bᴀᴄᴋ", callback_data = "start"),
            ]])            
        )
    elif data == "dev":
        await query.message.edit_text(
            text=Txt.DEV_TXT,
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup([[
                #⚠️ don't change source code & source link ⚠️ #
                InlineKeyboardButton("✗ Cʟᴏꜱᴇ", callback_data = "close"),
                InlineKeyboardButton("« Bᴀᴄᴋ", callback_data = "start")
            ]])          
        )
    elif data == "close":
        try:
            await query.message.delete()
            await query.message.reply_to_message.delete()
            await query.message.continue_propagation()
        except:
            await query.message.delete()
            await query.message.continue_propagation()
